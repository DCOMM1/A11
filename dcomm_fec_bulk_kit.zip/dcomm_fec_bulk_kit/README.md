# DCOMM FEC Bulk Ingest Production Kit

Public-record research / transparency database of U.S. Senate campaign finance.
Streams FEC bulk files without loading them into memory; full provenance.

**Organization:** DCOMM  
**Project:** A11 — Senate Campaign Finance Data Platform  
**Legal:** FEC contributor information may not be sold or used for commercial purposes or solicitation (2 U.S.C. §438(a)(4)).

## What is ready right now

| Artifact | Status |
|----------|--------|
| Streaming downloader (`fec_download.py`) | Ready |
| Current-cycle download script | Ready |
| Senate filter SQL (local + remote) | Ready |
| 2026 Senate universe (from real FEC files) | **Materialized** |
| Remote Hugging Face DuckDB prototype queries | Ready |
| Full 300 GB–2 TB Postgres dump ingest | Requires production hardware |

### Materialized 2026 Senate universe (this kit)

- **1 408** Senate candidates (`CAND_ID` starts with `S`)
- **1 250** candidate–committee linkage rows
- **1 020** unique authorized / linked committees
- Files under `data/processed/`:
  - `senate_candidates_2026.csv`
  - `senate_committee_links_2026.csv`
  - `senate_committee_ids_2026.txt`
  - `senate_committees_2026.csv`
  - `senate_universe_manifest.json`

## Immediate path: remote DuckDB (no download)

The public FEC DuckDB on Hugging Face contains ~280 M individual-contribution rows (2004–2026). Query it without local storage:

```bash
pip install duckdb
python scripts/query_remote_senate.py --cycle 2024 --limit 20
```

Or open a DuckDB CLI:

```sql
INSTALL httpfs; LOAD httpfs;
ATTACH 'https://huggingface.co/datasets/Nason/fec-database/resolve/main/fec.duckdb' AS fec (READ_ONLY);

-- See sql/remote_senate_gold.sql for full gold-mart views
SELECT c.CAND_NAME, c.CAND_PTY_AFFILIATION, c.CAND_OFFICE_ST,
       SUM(i.TRANSACTION_AMT) AS total, COUNT(*) AS donations
FROM fec.individual_contributions i
JOIN fec.candidates c ON i.CMTE_ID = c.CAND_PCC AND i.cycle = c.cycle
WHERE c.CAND_OFFICE = 'S' AND i.TRANSACTION_AMT > 0 AND c.cycle = 2024
GROUP BY 1,2,3 ORDER BY total DESC LIMIT 20;
```

## Production path (your machine with disk)

```bash
pip install -r requirements.txt
./scripts/download_current_cycle.sh          # fetches cn/ccl/cm/indiv + headers
python scripts/load_senate_cycle.py --cycle 2026
```

Filename convention is the official two-digit year: `cn26.zip`, `ccl26.zip`, `indiv26.zip`.

## Architecture

```
FEC weekly dump / cycle bulk files
        │
        ▼
RAW / IMMUTABLE  (original files + SHA-256 + timestamp)
        │
   ┌────┴────┐
   ▼         ▼
POSTGRES   PARQUET (partitioned by two-year period)
   │         │
   └────┬────┘
        ▼
DCOMM SILVER (normalize / link)
        │
   ┌────┼────┐
   ▼    ▼    ▼
CANDIDATES COMMITTEES CONTRIBUTORS
   │    │    │
   └────┼────┘
        ▼
CONTRIBUTIONS (fact + match_reason)
        │
        ▼
SENATE GOLD MART → SQL / API / Analytics
```

## Capacity guidance (FEC README)

- Postgres restore without indexes: ~300 GB  
- With indexes: ~2 TB  
- Current-cycle `indiv26.zip`: ~2.1 GB compressed  

## Push to GitHub

```bash
git clone https://github.com/DCOMM1/A11.git
cd A11
# copy this kit (or the zip) into the repo
git add dcomm_fec_bulk_kit/
git commit -m "Add FEC bulk ingest production kit + 2026 Senate universe"
git push
```

## Legal notice

The names and addresses of individual contributors may not be sold or used for any commercial purpose or to solicit any type of contribution or donation. 2 U.S.C. §438(a)(4); 11 CFR 104.15.

This project is structured as a public-record research and transparency database. Source provenance and the applicable-use restriction are documented in every artifact.
