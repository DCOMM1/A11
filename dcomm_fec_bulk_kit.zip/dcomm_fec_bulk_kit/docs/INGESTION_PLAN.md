# DCOMM FEC Ingestion Plan

## 1. Master inventory

| Dataset | FEC object | Priority | DCOMM use |
|---------|------------|----------|-----------|
| Schedule A (receipts) | `fec_fitem_sched_a` dump / `indivYY.zip` | 1 | Contributor + contribution database |
| Schedule B (disbursements) | `fec_fitem_sched_b` | 2 | Spending flows |
| Schedule E (independent expenditures) | `fec_fitem_sched_e` | 3 | Outside spending |
| Committee history | `ofec_committee_history` | 1 | Durable committee registry |
| Candidate master | `cnYY.zip` | 1 | Senate / House universe |
| Candidate–committee linkage | `cclYY.zip` | 1 | Join path candidate → committee |

## 2. Historical coverage (two-year cycles)

1975–1976 … 2025–2026 (current). The weekly PostgreSQL dump contains the full history partitioned by cycle. Cycle bulk files (`indivYY.zip` etc.) start later (generally 1980 onward for individual contributions).

## 3. Official source locations

- Cycle bulk index: https://www.fec.gov/data/browse-data/?tab=bulk-data
- Direct files: `https://www.fec.gov/files/bulk-downloads/{YYYY}/{prefix}{YY}.zip`
- PostgreSQL dump index: https://cg-519a459a-0ea3-42c2-b7bc-fa1143481f74.s3-us-gov-west-1.amazonaws.com/bulk-downloads/index.html?prefix=bulk-downloads/data-dump/schedules/
- README / restore instructions: https://www.fec.gov/files/bulk-downloads/data-dump/schedules/README.txt

## 4. Storage & ingestion strategy

### Raw / immutable layer
- Keep every downloaded zip or `.dump` file.
- Record SHA-256, byte size, retrieval timestamp in `source_manifest.json`.
- Never overwrite a previous successful download; version by date if needed.

### Partitioned analytical layer
- Prefer Parquet partitioned by `two_year_transaction_period` (or cycle).
- Alternative: native PostgreSQL tables restored from the official dump (FEC provides the schema).
- DuckDB is the recommended local development warehouse; the same SQL can later target Postgres / Snowflake.

### Senate-only extraction
1. Filter candidate master for `CAND_OFFICE = 'S'`.
2. Join candidate–committee linkage to obtain authorized / principal committees.
3. Restrict Schedule A / `indiv` rows to those `CMTE_ID`s.
4. Persist a `match_reason` column so every gold-layer row is auditable.
5. Keep a separate “current-cycle” Senate universe that can be refreshed weekly without touching historical snapshots.

### Weekly refresh
- Download the latest release.
- Verify checksum against previous manifest.
- Append / upsert only the delta into the silver and gold layers.
- Never delete historical raw snapshots.

## 5. Capacity planning (FEC guidance)

- Full dump without indexes: ~300 GB
- Full dump with indexes: ~2 TB
- Current-cycle `indiv26.zip`: ~2.1 GB compressed (grows over the cycle)

## 6. Legal & ethical guardrail

> The names and addresses of individual contributors may not be sold or used for any commercial purpose or to solicit any type of contribution or donation. 2 U.S.C. §438(a)(4); 11 CFR 104.15.

All published interfaces and documentation must surface this restriction. The project is a public-record research / transparency system.

## 7. Recommended implementation order

1. Current-cycle bulk files (cn / ccl / cm / indiv) → DuckDB Senate gold mart (this kit).
2. Expand to recent historical cycles (2020–2024) still using cycle bulk files.
3. Stage the full weekly PostgreSQL dump on production hardware and materialize partitioned Parquet.
4. Wire the silver / gold tables into the DCOMM FastAPI + analytics layer.
