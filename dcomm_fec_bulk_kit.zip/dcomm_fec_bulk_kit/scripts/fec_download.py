#!/usr/bin/env python3
"""
Memory-safe streaming downloader for FEC bulk files.

- Streams in 8 MB chunks
- Computes SHA-256 while downloading
- Records byte size and retrieval timestamp (UTC)
- Preserves the original file
- Writes / updates a provenance manifest
- Safe for files far larger than available RAM
"""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

import httpx
from tqdm import tqdm

CHUNK_SIZE = 8 * 1024 * 1024  # 8 MB
DEFAULT_MANIFEST = "source_manifest.json"
USER_AGENT = "DCOMM-FEC-Bulk-Ingest/1.0 (public-records research; contact: dcomm-project)"


def utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def load_manifest(path: Path) -> dict:
    if path.exists():
        return json.loads(path.read_text())
    return {"generated_by": "fec_download.py", "entries": []}


def save_manifest(path: Path, data: dict) -> None:
    path.write_text(json.dumps(data, indent=2, sort_keys=False) + "\n")


def download(
    url: str,
    dest: Path,
    manifest_path: Path,
    expected_size: Optional[int] = None,
    force: bool = False,
) -> dict:
    dest.parent.mkdir(parents=True, exist_ok=True)
    manifest = load_manifest(manifest_path)

    # Skip if already present and not forced
    if dest.exists() and not force:
        size = dest.stat().st_size
        print(f"[skip] {dest.name} already exists ({size:,} bytes). Use --force to re-download.")
        return {"status": "skipped", "path": str(dest), "bytes": size}

    print(f"[download] {url}")
    print(f"         → {dest}")

    sha = hashlib.sha256()
    bytes_written = 0
    started = time.monotonic()
    retrieved_at = utc_now()

    headers = {"User-Agent": USER_AGENT}
    with httpx.stream("GET", url, headers=headers, follow_redirects=True, timeout=120.0) as resp:
        resp.raise_for_status()
        total = int(resp.headers.get("content-length") or 0) or expected_size

        with open(dest, "wb") as f, tqdm(
            total=total,
            unit="B",
            unit_scale=True,
            unit_divisor=1024,
            desc=dest.name,
            disable=not sys.stderr.isatty(),
        ) as bar:
            for chunk in resp.iter_bytes(chunk_size=CHUNK_SIZE):
                if not chunk:
                    continue
                f.write(chunk)
                sha.update(chunk)
                n = len(chunk)
                bytes_written += n
                bar.update(n)

    elapsed = time.monotonic() - started
    checksum = sha.hexdigest()

    entry = {
        "url": url,
        "filename": dest.name,
        "local_path": str(dest.resolve()),
        "bytes": bytes_written,
        "sha256": checksum,
        "retrieved_at": retrieved_at,
        "elapsed_seconds": round(elapsed, 2),
        "content_type": resp.headers.get("content-type"),
    }

    # Update or append to manifest
    entries = [e for e in manifest.get("entries", []) if e.get("filename") != dest.name]
    entries.append(entry)
    manifest["entries"] = entries
    manifest["last_updated"] = retrieved_at
    save_manifest(manifest_path, manifest)

    print(f"[ok] {dest.name}: {bytes_written:,} bytes, sha256={checksum[:16]}…  ({elapsed:.1f}s)")
    return entry


def main() -> None:
    p = argparse.ArgumentParser(description="Streaming FEC bulk-file downloader with provenance.")
    p.add_argument("url", help="Full URL of the file to download")
    p.add_argument("-o", "--output", type=Path, required=True, help="Destination path")
    p.add_argument(
        "-m",
        "--manifest",
        type=Path,
        default=Path(DEFAULT_MANIFEST),
        help="Provenance manifest JSON (default: source_manifest.json)",
    )
    p.add_argument("--expected-size", type=int, default=None, help="Optional expected size for progress bar")
    p.add_argument("--force", action="store_true", help="Re-download even if file exists")
    args = p.parse_args()

    download(args.url, args.output, args.manifest, args.expected_size, args.force)


if __name__ == "__main__":
    main()
