#!/usr/bin/env bash
# Download the essential 2025-2026 FEC bulk files for the Senate MVP / gold-mart path.
# Safe to re-run; existing files are skipped unless FORCE=1.
set -euo pipefail

CYCLE=2026
BASE="https://www.fec.gov/files/bulk-downloads"
DICT="${BASE}/data_dictionaries"
OUTDIR="${1:-./data/raw/fec/${CYCLE}}"
MANIFEST="${OUTDIR}/source_manifest.json"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PYTHON="${PYTHON:-python3}"

mkdir -p "${OUTDIR}"

echo "=== DCOMM FEC current-cycle download (cycle=${CYCLE}) ==="
echo "Output directory: ${OUTDIR}"
echo

download() {
  local url="$1"
  local dest="$2"
  local force_flag=""
  if [[ "${FORCE:-0}" == "1" ]]; then
    force_flag="--force"
  fi
  "${PYTHON}" "${SCRIPT_DIR}/fec_download.py" "${url}" -o "${dest}" -m "${MANIFEST}" ${force_flag}
}

# Headers (tiny)
download "${DICT}/cn_header_file.csv"   "${OUTDIR}/cn_header_file.csv"
download "${DICT}/ccl_header_file.csv"  "${OUTDIR}/ccl_header_file.csv"
download "${DICT}/cm_header_file.csv"   "${OUTDIR}/cm_header_file.csv"
download "${DICT}/indiv_header_file.csv" "${OUTDIR}/indiv_header_file.csv"

# Master / linkage files (small)
download "${BASE}/${CYCLE}/cn${CYCLE: -2}.zip"  "${OUTDIR}/cn${CYCLE: -2}.zip"
download "${BASE}/${CYCLE}/ccl${CYCLE: -2}.zip" "${OUTDIR}/ccl${CYCLE: -2}.zip"
download "${BASE}/${CYCLE}/cm${CYCLE: -2}.zip"  "${OUTDIR}/cm${CYCLE: -2}.zip"

# Individual contributions – ~2.1 GB compressed (as of 2026)
echo
echo "NOTE: indiv${CYCLE: -2}.zip is approximately 2.1 GB. This will take several minutes."
download "${BASE}/${CYCLE}/indiv${CYCLE: -2}.zip" "${OUTDIR}/indiv${CYCLE: -2}.zip"

echo
echo "=== Download complete ==="
echo "Manifest: ${MANIFEST}"
ls -lh "${OUTDIR}"
