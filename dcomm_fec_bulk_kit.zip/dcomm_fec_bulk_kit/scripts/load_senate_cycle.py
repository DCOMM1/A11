#!/usr/bin/env python3
"""
Load a single FEC cycle's bulk files into DuckDB, extract the Senate universe,
and materialize the gold mart.

Designed for low-memory environments: uses DuckDB's native ZIP + CSV readers
and never materializes the full individual-contributions table in Python.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import duckdb

# Official header order for the pipe-delimited bulk files
# (source: FEC data_dictionaries/*_header_file.csv)
CN_COLS = [
    "CAND_ID", "CAND_NAME", "CAND_PTY_AFFILIATION", "CAND_ELECTION_YR",
    "CAND_OFFICE_ST", "CAND_OFFICE", "CAND_OFFICE_DISTRICT", "CAND_ICI",
    "CAND_STATUS", "CAND_PCC", "CAND_ST1", "CAND_ST2", "CAND_CITY",
    "CAND_ST", "CAND_ZIP",
]

CCL_COLS = [
    "CAND_ID", "CAND_ELECTION_YR", "FEC_ELECTION_YR", "CMTE_ID",
    "CMTE_TP", "CMTE_DSGN", "LINKAGE_ID",
]

CM_COLS = [
    "CMTE_ID", "CMTE_NM", "TRES_NM", "CMTE_ST1", "CMTE_ST2", "CMTE_CITY",
    "CMTE_ST", "CMTE_ZIP", "CMTE_DSGN", "CMTE_TP", "CMTE_PTY_AFFILIATION",
    "CMTE_FILING_FREQ", "ORG_TP", "CONNECTED_ORG_NM", "CAND_ID",
]

INDIV_COLS = [
    "CMTE_ID", "AMNDT_IND", "RPT_TP", "TRANSACTION_PGI", "IMAGE_NUM",
    "TRANSACTION_TP", "ENTITY_TP", "NAME", "CITY", "STATE", "ZIP_CODE",
    "EMPLOYER", "OCCUPATION", "TRANSACTION_DT", "TRANSACTION_AMT",
    "OTHER_ID", "TRAN_ID", "FILE_NUM", "MEMO_CD", "MEMO_TEXT", "SUB_ID",
]


def read_header(path: Path) -> list[str]:
    """Read a FEC header CSV (single line, comma-separated)."""
    text = path.read_text().strip()
    return [c.strip() for c in text.split(",")]


def load_zip_txt(con: duckdb.DuckDBPyConnection, zip_path: Path, cols: list[str], view_name: str) -> None:
    """Create a DuckDB view over the single .txt member inside a FEC zip."""
    # DuckDB can read zip members directly
    zip_glob = str(zip_path) + "/*.txt"
    col_list = ", ".join(f'"{c}"' for c in cols)
    # We force the column list because the files have no header row
    con.execute(f"""
        CREATE OR REPLACE VIEW {view_name} AS
        SELECT * FROM read_csv(
            '{zip_glob}',
            delim='|',
            header=false,
            columns={{{', '.join(f"'{c}': 'VARCHAR'" for c in cols)}}},
            quote='',
            escape='',
            nullstr='',
            ignore_errors=true,
            parallel=true
        )
    """)
    n = con.execute(f"SELECT COUNT(*) FROM {view_name}").fetchone()[0]
    print(f"  {view_name}: {n:,} rows")


def main() -> None:
    p = argparse.ArgumentParser(description="Load FEC cycle bulk files and extract Senate gold mart")
    p.add_argument("--cycle", type=int, default=2026, help="Election cycle year (e.g. 2026)")
    p.add_argument(
        "--raw-dir",
        type=Path,
        default=None,
        help="Directory containing the downloaded zip + header files (default: data/raw/fec/{cycle})",
    )
    p.add_argument(
        "--db",
        type=Path,
        default=Path("data/processed/senate_cycle.duckdb"),
        help="Output DuckDB database path",
    )
    p.add_argument("--sql", type=Path, default=Path("sql/senate_filter.sql"), help="Path to senate_filter.sql")
    args = p.parse_args()

    cycle = args.cycle
    yy = str(cycle)[-2:]
    raw_dir = args.raw_dir or Path(f"data/raw/fec/{cycle}")
    if not raw_dir.exists():
        print(f"ERROR: raw directory not found: {raw_dir}", file=sys.stderr)
        print("Run scripts/download_current_cycle.sh first.", file=sys.stderr)
        sys.exit(1)

    args.db.parent.mkdir(parents=True, exist_ok=True)
    print(f"Opening DuckDB → {args.db}")
    con = duckdb.connect(str(args.db))

    # Prefer header files if present, otherwise fall back to hard-coded lists
    def cols_for(prefix: str, fallback: list[str]) -> list[str]:
        hdr = raw_dir / f"{prefix}_header_file.csv"
        if hdr.exists():
            return read_header(hdr)
        return fallback

    print("Loading candidate master …")
    load_zip_txt(con, raw_dir / f"cn{yy}.zip", cols_for("cn", CN_COLS), "raw_cn")

    print("Loading candidate–committee linkage …")
    load_zip_txt(con, raw_dir / f"ccl{yy}.zip", cols_for("ccl", CCL_COLS), "raw_ccl")

    cm_zip = raw_dir / f"cm{yy}.zip"
    if cm_zip.exists():
        print("Loading committee master …")
        load_zip_txt(con, cm_zip, cols_for("cm", CM_COLS), "raw_cm")

    indiv_zip = raw_dir / f"indiv{yy}.zip"
    if not indiv_zip.exists():
        print(f"ERROR: {indiv_zip} not found. Download it first.", file=sys.stderr)
        sys.exit(1)

    print("Loading individual contributions (this may take a few minutes) …")
    load_zip_txt(con, indiv_zip, cols_for("indiv", INDIV_COLS), "raw_indiv")

    print("Running Senate filter SQL …")
    sql = args.sql.read_text()
    con.execute(sql)

    # Quick summary
    n_cand = con.execute("SELECT COUNT(*) FROM senate_candidates").fetchone()[0]
    n_cmte = con.execute("SELECT COUNT(*) FROM senate_committees").fetchone()[0]
    n_contrib = con.execute("SELECT COUNT(*) FROM mart_senate_contributions").fetchone()[0]
    print()
    print("=== Senate gold mart summary ===")
    print(f"  Senate candidates : {n_cand:,}")
    print(f"  Linked committees : {n_cmte:,}")
    print(f"  Contributions     : {n_contrib:,}")
    print(f"Database written to : {args.db.resolve()}")
    con.close()


if __name__ == "__main__":
    main()
