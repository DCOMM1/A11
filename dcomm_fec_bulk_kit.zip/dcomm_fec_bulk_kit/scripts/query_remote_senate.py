#!/usr/bin/env python3
"""
Prototype the Senate gold mart against the public FEC DuckDB on Hugging Face.

No local download of the multi-hundred-GB dump is required. DuckDB uses HTTP
range requests so only the pages touched by the query are fetched.

Requires: duckdb  (pip install duckdb)

Usage:
  python scripts/query_remote_senate.py
  python scripts/query_remote_senate.py --cycle 2024 --limit 20
"""

from __future__ import annotations

import argparse
import sys

try:
    import duckdb
except ImportError:
    print("duckdb is required:  pip install duckdb", file=sys.stderr)
    sys.exit(1)

HF_URL = "https://huggingface.co/datasets/Nason/fec-database/resolve/main/fec.duckdb"


def main() -> None:
    p = argparse.ArgumentParser(description="Query remote FEC DuckDB for Senate contributions")
    p.add_argument("--cycle", type=int, default=None, help="Limit to one election cycle (e.g. 2024)")
    p.add_argument("--limit", type=int, default=25, help="Rows to return for top lists")
    args = p.parse_args()

    con = duckdb.connect()
    con.execute("INSTALL httpfs; LOAD httpfs;")
    con.execute(f"ATTACH '{HF_URL}' AS fec (READ_ONLY);")

    cycle_clause = f"AND c.cycle = {args.cycle}" if args.cycle else ""

    print("=== Senate candidates by cycle (sample) ===")
    print(con.execute(f"""
        SELECT cycle, COUNT(*) AS n
        FROM fec.candidates
        WHERE CAND_OFFICE = 'S' {cycle_clause.replace('c.cycle', 'cycle') if args.cycle else ''}
        GROUP BY 1 ORDER BY 1 DESC
        LIMIT 10
    """).fetchdf().to_string(index=False))

    print("\n=== Top Senate candidates by individual receipts ===")
    q = f"""
        SELECT
            c.CAND_ID,
            c.CAND_NAME,
            c.CAND_PTY_AFFILIATION AS party,
            c.CAND_OFFICE_ST AS state,
            c.cycle,
            SUM(i.TRANSACTION_AMT) AS total_individual,
            COUNT(*) AS num_donations
        FROM fec.individual_contributions i
        JOIN fec.candidates c
          ON i.CMTE_ID = c.CAND_PCC
         AND i.cycle = c.cycle
        WHERE c.CAND_OFFICE = 'S'
          AND i.TRANSACTION_AMT > 0
          {cycle_clause}
        GROUP BY 1,2,3,4,5
        ORDER BY total_individual DESC
        LIMIT {args.limit}
    """
    print(con.execute(q).fetchdf().to_string(index=False))

    print("\n=== Top individual donors to Senate candidates ===")
    q2 = f"""
        SELECT
            i.NAME AS contributor_name,
            i.EMPLOYER,
            i.OCCUPATION,
            i.STATE AS contributor_state,
            SUM(i.TRANSACTION_AMT) AS total_donated,
            COUNT(*) AS num_donations,
            COUNT(DISTINCT c.CAND_ID) AS num_senate_candidates
        FROM fec.individual_contributions i
        JOIN fec.candidates c
          ON i.CMTE_ID = c.CAND_PCC
         AND i.cycle = c.cycle
        WHERE c.CAND_OFFICE = 'S'
          AND i.TRANSACTION_AMT > 0
          {cycle_clause}
        GROUP BY 1,2,3,4
        ORDER BY total_donated DESC
        LIMIT {args.limit}
    """
    print(con.execute(q2).fetchdf().to_string(index=False))

    print("\n=== Senate contribution volume by cycle ===")
    print(con.execute("""
        SELECT
            c.cycle,
            COUNT(DISTINCT c.CAND_ID) AS senate_candidates,
            COUNT(*) AS donations,
            SUM(i.TRANSACTION_AMT) AS total_amount
        FROM fec.individual_contributions i
        JOIN fec.candidates c
          ON i.CMTE_ID = c.CAND_PCC
         AND i.cycle = c.cycle
        WHERE c.CAND_OFFICE = 'S'
          AND i.TRANSACTION_AMT > 0
        GROUP BY 1
        ORDER BY 1
    """).fetchdf().to_string(index=False))

    print("\nDone. Remote query used only the pages required by the SQL.")
    print("Legal: FEC contributor data may not be sold or used for commercial purposes or solicitation (2 U.S.C. §438(a)(4)).")


if __name__ == "__main__":
    main()
