-- Senate-universe extraction for a single FEC cycle (pipe-delimited bulk files).
-- Assumes the following DuckDB views / tables have already been created from the
-- corresponding zip files:
--   raw_cn   (candidate master)
--   raw_ccl  (candidate-committee linkage)
--   raw_cm   (committee master)          -- optional but useful
--   raw_indiv (individual contributions / Schedule A subset)
--
-- The gold layer preserves every original FEC field plus a match_reason column
-- so the extraction is fully auditable.

-- 1. Senate candidates for the cycle
CREATE OR REPLACE TABLE senate_candidates AS
SELECT
    CAND_ID          AS candidate_id,
    CAND_NAME        AS candidate_name,
    CAND_PTY_AFFILIATION AS party,
    CAND_ELECTION_YR AS election_year,
    CAND_OFFICE      AS office,
    CAND_OFFICE_ST   AS office_state,
    CAND_OFFICE_DISTRICT AS district,
    CAND_ICI         AS incumbent_challenger_status,
    CAND_STATUS      AS candidate_status,
    CAND_PCC         AS principal_committee_id,
    CAND_ST1, CAND_ST2, CAND_CITY, CAND_ST, CAND_ZIP
FROM raw_cn
WHERE CAND_OFFICE = 'S';

-- 2. Authorized committees linked to those Senate candidates
CREATE OR REPLACE TABLE senate_committees AS
SELECT DISTINCT
    ccl.CAND_ID   AS candidate_id,
    ccl.CMTE_ID   AS committee_id,
    ccl.CMTE_TP   AS committee_type,
    ccl.CMTE_DSGN AS committee_designation,
    ccl.LINKAGE_ID,
    CASE
        WHEN ccl.CMTE_DSGN = 'P' THEN 'principal'
        WHEN ccl.CMTE_DSGN = 'A' THEN 'authorized'
        ELSE 'other_linked'
    END AS link_role
FROM raw_ccl ccl
INNER JOIN senate_candidates sc ON sc.candidate_id = ccl.CAND_ID;

-- 3. Gold-level individual contributions to Senate committees
--    (keeps every original field + match metadata)
CREATE OR REPLACE TABLE mart_senate_contributions AS
SELECT
    i.*,
    sc.candidate_id,
    sc.candidate_name,
    sc.party              AS candidate_party,
    sc.office_state,
    sc.election_year,
    scm.link_role,
    scm.committee_designation,
    'senate_authorized_committee' AS match_reason,
    current_timestamp     AS extracted_at
FROM raw_indiv i
INNER JOIN senate_committees scm ON scm.committee_id = i.CMTE_ID
INNER JOIN senate_candidates sc  ON sc.candidate_id  = scm.candidate_id;

-- 4. Convenience aggregate: top donors per Senate candidate
CREATE OR REPLACE VIEW mart_senate_top_donors AS
SELECT
    candidate_id,
    candidate_name,
    office_state,
    party AS candidate_party,
    NAME AS contributor_name,
    EMPLOYER,
    OCCUPATION,
    CITY,
    STATE AS contributor_state,
    ZIP_CODE,
    SUM(TRANSACTION_AMT) AS total_amount,
    COUNT(*)             AS transaction_count,
    MIN(TRANSACTION_DT)  AS first_gift,
    MAX(TRANSACTION_DT)  AS last_gift
FROM mart_senate_contributions
WHERE TRANSACTION_AMT > 0
GROUP BY 1,2,3,4,5,6,7,8,9,10
ORDER BY candidate_id, total_amount DESC;
