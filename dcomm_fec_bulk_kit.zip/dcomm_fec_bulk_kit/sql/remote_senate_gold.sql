-- DCOMM Senate gold mart against the public Hugging Face FEC DuckDB
-- https://huggingface.co/datasets/Nason/fec-database
--
-- Run after:
--   INSTALL httpfs; LOAD httpfs;
--   ATTACH 'https://huggingface.co/datasets/Nason/fec-database/resolve/main/fec.duckdb' AS fec (READ_ONLY);

-- 1. Senate candidate universe
CREATE OR REPLACE VIEW senate_candidates AS
SELECT
    CAND_ID,
    CAND_NAME,
    CAND_PTY_AFFILIATION AS party,
    CAND_OFFICE_ST AS office_state,
    CAND_OFFICE AS office,
    CAND_OFFICE_DISTRICT AS district,
    CAND_ELECTION_YR AS election_year,
    CAND_STATUS AS status,
    CAND_PCC AS principal_committee_id,
    cycle
FROM fec.candidates
WHERE CAND_OFFICE = 'S';

-- 2. Authorized / linked committees (via candidate_committee_links + PCC)
CREATE OR REPLACE VIEW senate_committees AS
SELECT DISTINCT
    l.CAND_ID,
    l.CMTE_ID,
    l.CMTE_TP,
    l.CMTE_DSGN,
    c.CAND_NAME,
    c.party,
    c.office_state,
    c.cycle,
    'senate_authorized_or_linked' AS match_reason
FROM fec.candidate_committee_links l
JOIN senate_candidates c ON c.CAND_ID = l.CAND_ID AND c.cycle = l.cycle;

-- 3. Individual contributions to Senate principal campaign committees
--    (primary path: join on CAND_PCC)
CREATE OR REPLACE VIEW senate_contributions_via_pcc AS
SELECT
    i.*,
    c.CAND_ID,
    c.CAND_NAME,
    c.party,
    c.office_state,
    c.cycle AS candidate_cycle,
    'senate_principal_committee' AS match_reason
FROM fec.individual_contributions i
JOIN fec.candidates c
  ON i.CMTE_ID = c.CAND_PCC
 AND i.cycle = c.cycle
WHERE c.CAND_OFFICE = 'S'
  AND i.TRANSACTION_AMT IS NOT NULL;

-- 4. Gold mart: per-candidate totals
CREATE OR REPLACE VIEW mart_senate_candidate_totals AS
SELECT
    CAND_ID,
    CAND_NAME,
    party,
    office_state,
    candidate_cycle AS cycle,
    COUNT(*) AS num_donations,
    SUM(TRANSACTION_AMT) AS total_individual,
    AVG(TRANSACTION_AMT) AS avg_donation
FROM senate_contributions_via_pcc
WHERE TRANSACTION_AMT > 0
GROUP BY 1,2,3,4,5;

-- 5. Gold mart: top donors across Senate races
CREATE OR REPLACE VIEW mart_senate_top_donors AS
SELECT
    NAME AS contributor_name,
    EMPLOYER,
    OCCUPATION,
    STATE AS contributor_state,
    COUNT(*) AS num_donations,
    SUM(TRANSACTION_AMT) AS total_donated,
    COUNT(DISTINCT CAND_ID) AS num_senate_candidates,
    MIN(candidate_cycle) AS first_cycle,
    MAX(candidate_cycle) AS last_cycle
FROM senate_contributions_via_pcc
WHERE TRANSACTION_AMT > 0
GROUP BY 1,2,3,4
ORDER BY total_donated DESC;

-- Example: top 20 Senate candidates by individual receipts in 2024
-- SELECT * FROM mart_senate_candidate_totals WHERE cycle = 2024 ORDER BY total_individual DESC LIMIT 20;
