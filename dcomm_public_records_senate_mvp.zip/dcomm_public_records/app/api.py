from pathlib import Path
import os
import duckdb
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Query

ROOT = Path(__file__).resolve().parents[1]
load_dotenv(ROOT / ".env")
DB = ROOT / os.getenv("DATABASE_PATH", "data/dcomm_public_records.duckdb")
app = FastAPI(title="DCOMM Public Records API", version="0.1.0")

def db(): return duckdb.connect(str(DB), read_only=False)

@app.get("/health")
def health(): return {"status":"ok", "database": str(DB)}

@app.get("/api/v1/senate/candidates")
def senate_candidates(limit: int = Query(100, le=500)):
    con=db()
    rows=con.execute("SELECT candidate_id,candidate_name,party,election_year,office_state,district,principal_committee_id FROM candidates WHERE office='S' ORDER BY office_state,candidate_name LIMIT ?", [limit]).fetchdf().to_dict("records")
    con.close(); return rows

@app.get("/api/v1/officials/{official_id}")
def official(official_id: str):
    con=db(); row=con.execute("SELECT * FROM officials WHERE official_id=?", [official_id]).fetchone(); con.close()
    if not row: raise HTTPException(404, "Official not found")
    return dict(zip([d[0] for d in con.description], row)) if False else row

@app.get("/api/v1/officials/{official_id}/top-donors")
def top_donors(official_id: str, limit: int = Query(20, le=200)):
    con=db()
    rows=con.execute("""
      SELECT contributor_id, contributor_name, employer, occupation, contributor_state,
             total_contributed, transaction_count
      FROM mart_senate_top_donors
      WHERE candidate_id=? ORDER BY total_contributed DESC LIMIT ?
    """, [official_id, limit]).fetchdf().to_dict("records")
    con.close(); return {"official_id":official_id,"top_donors":rows}

@app.get("/api/v1/search/contributors")
def search_contributors(q: str, limit: int = Query(25, le=100)):
    con=db()
    rows=con.execute("""
      SELECT contributor_id, normalized_name, employer, occupation, city, state, resolution_status
      FROM contributors
      WHERE lower(normalized_name) LIKE lower(?)
         OR lower(coalesce(employer,'')) LIKE lower(?)
      ORDER BY normalized_name LIMIT ?
    """, [f"%{q}%",f"%{q}%",limit]).fetchdf().to_dict("records")
    con.close(); return rows
