CREATE TABLE IF NOT EXISTS officials (
    official_id VARCHAR PRIMARY KEY,
    full_name VARCHAR NOT NULL,
    office_level VARCHAR NOT NULL,
    office_type VARCHAR NOT NULL,
    jurisdiction VARCHAR,
    state VARCHAR,
    party VARCHAR,
    current_status VARCHAR,
    source_url VARCHAR,
    source_updated_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT current_timestamp
);

CREATE TABLE IF NOT EXISTS candidates (
    candidate_id VARCHAR PRIMARY KEY,
    candidate_name VARCHAR,
    party VARCHAR,
    election_year INTEGER,
    office VARCHAR,
    office_state VARCHAR,
    district VARCHAR,
    incumbent_challenger_status VARCHAR,
    candidate_status VARCHAR,
    principal_committee_id VARCHAR,
    raw_source VARCHAR DEFAULT 'FEC API',
    ingested_at TIMESTAMP DEFAULT current_timestamp
);

CREATE TABLE IF NOT EXISTS committees (
    committee_id VARCHAR PRIMARY KEY,
    committee_name VARCHAR,
    committee_type VARCHAR,
    committee_designation VARCHAR,
    committee_party VARCHAR,
    state VARCHAR,
    candidate_id VARCHAR,
    raw_source VARCHAR DEFAULT 'FEC API',
    ingested_at TIMESTAMP DEFAULT current_timestamp
);

CREATE TABLE IF NOT EXISTS candidate_committee_links (
    candidate_id VARCHAR,
    committee_id VARCHAR,
    is_principal BOOLEAN,
    PRIMARY KEY(candidate_id, committee_id)
);

CREATE TABLE IF NOT EXISTS contributors (
    contributor_id VARCHAR PRIMARY KEY,
    normalized_name VARCHAR NOT NULL,
    employer VARCHAR,
    occupation VARCHAR,
    city VARCHAR,
    state VARCHAR,
    zip VARCHAR,
    contributor_type VARCHAR,
    resolution_status VARCHAR DEFAULT 'unresolved'
);

CREATE TABLE IF NOT EXISTS fact_contributions (
    contribution_id VARCHAR PRIMARY KEY,
    committee_id VARCHAR,
    candidate_id VARCHAR,
    contributor_id VARCHAR,
    contributor_name_raw VARCHAR,
    transaction_date DATE,
    amount DECIMAL(18,2),
    memoed_subtotal BOOLEAN,
    transaction_type VARCHAR,
    entity_type VARCHAR,
    filing_id VARCHAR,
    sub_id VARCHAR,
    source_url VARCHAR,
    source_retrieved_at TIMESTAMP DEFAULT current_timestamp
);

CREATE TABLE IF NOT EXISTS ingestion_runs (
    run_id VARCHAR PRIMARY KEY,
    source VARCHAR,
    endpoint VARCHAR,
    started_at TIMESTAMP,
    completed_at TIMESTAMP,
    records_received INTEGER,
    status VARCHAR,
    error_message VARCHAR
);

CREATE OR REPLACE VIEW mart_senate_top_donors AS
SELECT
    c.candidate_id,
    COALESCE(ca.candidate_name, c.candidate_id) AS candidate_name,
    f.contributor_id,
    MAX(f.contributor_name_raw) AS contributor_name,
    MAX(cr.employer) AS employer,
    MAX(cr.occupation) AS occupation,
    MAX(cr.state) AS contributor_state,
    SUM(f.amount) AS total_contributed,
    COUNT(*) AS transaction_count
FROM fact_contributions f
LEFT JOIN candidates ca ON ca.candidate_id = f.candidate_id
LEFT JOIN contributors cr ON cr.contributor_id = f.contributor_id
LEFT JOIN committees c ON c.committee_id = f.committee_id
WHERE c.committee_id IS NOT NULL
GROUP BY 1,2,3;
