# DCOMM Public Records / Campaign Finance Database — Senate MVP

A first working scaffold for a public-records research database, starting with U.S. Senate campaign finance.

## Architecture

1. **Ingestion** — FEC API / bulk files -> raw JSON/CSV
2. **Transform** — DuckDB SQL -> normalized tables + analytical marts
3. **Serving** — FastAPI + optional Streamlit dashboard

The design deliberately separates:
- `raw_*`: source-faithful records retained for provenance
- `stg_*`: standardized records
- `dim_*`: officials, candidates, committees, contributors
- `fact_contributions`: transaction-level receipts
- `mart_*`: public-facing aggregates

## Why DuckDB first?

It gives us a real SQL database/warehouse locally without paying for Snowflake before the data model is proven. The schema can later move to PostgreSQL or Snowflake with minimal conceptual change.

## Federal scope — Senate MVP

The FEC is the authoritative source for federal campaign-finance filings. FEC data is updated nightly, and Schedule A contains itemized receipts including individual contributions. See the official FEC documentation linked in the project notes.

Important modeling point: money is reported to **committees**, not directly to a person. The model therefore links:

`official -> candidate -> authorized committee -> contribution -> contributor`

This avoids incorrectly attributing a committee receipt directly to an officeholder.

## Setup

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e .
cp .env.example .env
```

Set `FEC_API_KEY` in `.env`. `DEMO_KEY` can be used for limited exploration, but a personal FEC API key is preferable for sustained ingestion.

## Initialize database

```bash
python scripts/init_db.py
```

## Ingest Senate candidates

```bash
python scripts/ingest_fec.py candidates --office S --election-cycle 2026
```

## Ingest a candidate's committees and Schedule A receipts

```bash
python scripts/ingest_fec.py candidate --candidate-id S00003392 --election-cycle 2026
```

Replace the candidate ID with the FEC ID for the Senate candidate/official being researched.

## Transform

```bash
python scripts/transform.py
```

## Run API

```bash
uvicorn app.api:app --reload
```

Then visit `/docs` for the interactive API documentation.

## Initial API endpoints

- `GET /health`
- `GET /api/v1/senate/candidates`
- `GET /api/v1/officials/{official_id}`
- `GET /api/v1/officials/{official_id}/top-donors`
- `GET /api/v1/committees/{committee_id}/contributions`
- `GET /api/v1/search/contributors?q=...`

## Public-data design rule

Keep source-faithful raw data internally for auditability, but publish a minimized analytical layer. Do not expose unnecessary personal contact information. Preserve source identifiers, filing IDs, transaction IDs, dates, amounts, employer/occupation when legally appropriate, and source provenance.

## Next expansion

After the Senate MVP is stable:
1. House
2. State-level campaign finance portals
3. Municipal/county ethics records
4. Other public-official records
5. Cross-jurisdiction contributor/entity resolution
6. Public search and network visualization

This is intended as a research/transparency platform, not a solicitation list.

## Seed the current Senate roster

The repository includes a 119th Congress Senate roster snapshot based on the official Senate roster.

```bash
python scripts/seed_senators.py
```

Then ingest FEC Senate candidates and review name/state matches:

```bash
python scripts/ingest_fec.py candidates --office S --election-cycle 2026
python scripts/link_senators.py
```

The roster and FEC candidate identities are intentionally separate. An officeholder is not automatically the same thing as a candidate record.
