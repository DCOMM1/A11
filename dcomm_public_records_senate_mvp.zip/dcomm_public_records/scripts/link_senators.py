from pathlib import Path
import re, duckdb
ROOT=Path(__file__).resolve().parents[1]
DB=ROOT/'data/dcomm_public_records.duckdb'

def norm(s):
    return re.sub(r'[^a-z ]','',(s or '').lower()).replace(' jr ',' ').replace(' iii ',' ').strip()
con=duckdb.connect(str(DB))
offs=con.execute("select official_id,full_name,state from officials where office_type='US Senate'").fetchall()
cands=con.execute("select candidate_id,candidate_name,office_state from candidates where office='S'").fetchall()
matched=0
for oid,name,state in offs:
    target=norm(name)
    hits=[c for c in cands if norm(c[1])==target and c[2]==state]
    if hits:
        con.execute("update officials set source_updated_at=current_timestamp where official_id=?",[oid])
        matched += 1
print(f'Exact Senate name/state matches available: {matched}/{len(offs)}')
print('Candidate linkage should be reviewed manually where names changed, incumbents are unopposed, or the FEC candidate record is not the officeholder record.')
con.close()
