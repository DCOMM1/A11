import argparse, hashlib, json, os
from datetime import datetime, timezone
from pathlib import Path
import duckdb, httpx
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parents[1]
load_dotenv(ROOT / ".env")
BASE = os.getenv("FEC_BASE_URL", "https://api.open.fec.gov/v1")
KEY = os.getenv("FEC_API_KEY", "DEMO_KEY")
DB = ROOT / os.getenv("DATABASE_PATH", "data/dcomm_public_records.duckdb")
RAW = ROOT / "data" / "raw" / "fec"
RAW.mkdir(parents=True, exist_ok=True)


def get_json(path, params):
    params = dict(params)
    params["api_key"] = KEY
    with httpx.Client(timeout=60) as client:
        r = client.get(f"{BASE}{path}", params=params)
        r.raise_for_status()
        return r.json()


def save_raw(name, payload):
    p = RAW / name
    p.write_text(json.dumps(payload, indent=2))
    return p


def upsert_candidates(payload):
    con = duckdb.connect(str(DB))
    rows = payload.get("results", [])
    for x in rows:
        con.execute("""
        INSERT OR REPLACE INTO candidates
        (candidate_id,candidate_name,party,election_year,office,office_state,district,
         incumbent_challenger_status,candidate_status,principal_committee_id)
        VALUES (?,?,?,?,?,?,?,?,?,?)
        """, [x.get("candidate_id"), x.get("name"), x.get("party"), x.get("election_year"),
               x.get("office"), x.get("state"), x.get("district"), x.get("incumbent_challenge"),
               x.get("candidate_status"), x.get("principal_committees", [None])[0] if x.get("principal_committees") else None])
    con.close()
    return len(rows)


def ingest_candidates(office, election_cycle):
    payload = get_json("/candidates/", {
        "office": office,
        "election_year": election_cycle,
        "is_active_candidate": "true",
        "per_page": 100,
        "page": 1,
    })
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    save_raw(f"candidates_{office}_{election_cycle}_{stamp}.json", payload)
    n = upsert_candidates(payload)
    print(f"Loaded {n} candidate records")


def ingest_candidate(candidate_id, election_cycle):
    committees = get_json(f"/candidate/{candidate_id}/committees/", {
        "election_year": election_cycle, "per_page": 100
    })
    save_raw(f"candidate_{candidate_id}_committees.json", committees)
    con = duckdb.connect(str(DB))
    for x in committees.get("results", []):
        cid = x.get("committee_id")
        con.execute("""
        INSERT OR REPLACE INTO committees
        (committee_id,committee_name,committee_type,committee_designation,committee_party,state,candidate_id)
        VALUES (?,?,?,?,?,?,?)
        """, [cid, x.get("name"), x.get("committee_type"), x.get("designation"),
               x.get("party"), x.get("state"), candidate_id])
        con.execute("INSERT OR REPLACE INTO candidate_committee_links VALUES (?,?,?)",
                    [candidate_id, cid, x.get("designation") == "P"])
    con.close()
    print(f"Loaded {len(committees.get('results', []))} committees for {candidate_id}")

    for x in committees.get("results", []):
        cmte = x.get("committee_id")
        if not cmte:
            continue
        payload = get_json("/schedules/schedule_a/", {
            "committee_id": cmte,
            "two_year_transaction_period": election_cycle,
            "is_individual": "true",
            "per_page": 100,
            "page": 1,
        })
        save_raw(f"schedule_a_{cmte}_{election_cycle}.json", payload)
        load_schedule_a(payload, candidate_id, cmte)


def contributor_key(name, employer, city, state, zip_code):
    raw = "|".join((name or "", employer or "", city or "", state or "", zip_code or "")).upper()
    return hashlib.sha256(raw.encode()).hexdigest()[:32]


def load_schedule_a(payload, candidate_id, committee_id):
    con = duckdb.connect(str(DB))
    count = 0
    for x in payload.get("results", []):
        name = x.get("contributor_name") or x.get("contributor_name_text")
        emp = x.get("contributor_employer")
        city = x.get("contributor_city")
        state = x.get("contributor_state")
        zip_code = x.get("contributor_zip")
        contributor_id = contributor_key(name, emp, city, state, zip_code)
        con.execute("""
        INSERT OR REPLACE INTO contributors
        VALUES (?,?,?,?,?,?,?, ?, COALESCE((SELECT resolution_status FROM contributors WHERE contributor_id=?),'unresolved'))
        """, [contributor_id, name or "", emp, x.get("contributor_occupation"), city, state, zip_code,
               x.get("entity_type"), contributor_id])
        tran_id = x.get("sub_id") or x.get("transaction_id") or f"{committee_id}:{x.get('transaction_number')}:{x.get('contribution_receipt_date')}"
        contribution_id = hashlib.sha256(f"{committee_id}|{tran_id}".encode()).hexdigest()
        con.execute("""
        INSERT OR REPLACE INTO fact_contributions
        (contribution_id,committee_id,candidate_id,contributor_id,contributor_name_raw,transaction_date,amount,
         memoed_subtotal,transaction_type,entity_type,filing_id,sub_id,source_url)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, [contribution_id, committee_id, candidate_id, contributor_id, name,
               x.get("contribution_receipt_date"), x.get("contribution_receipt_amount"),
               bool(x.get("memoed_subtotal")), x.get("transaction_type"), x.get("entity_type"),
               x.get("file_number"), x.get("sub_id"), "https://www.fec.gov/data/receipts/"])
        count += 1
    con.close()
    print(f"Loaded {count} Schedule A records for {committee_id}")


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    sub = p.add_subparsers(dest="cmd", required=True)
    a = sub.add_parser("candidates")
    a.add_argument("--office", default="S")
    a.add_argument("--election-cycle", type=int, default=2026)
    b = sub.add_parser("candidate")
    b.add_argument("--candidate-id", required=True)
    b.add_argument("--election-cycle", type=int, default=2026)
    args = p.parse_args()
    if args.cmd == "candidates": ingest_candidates(args.office, args.election_cycle)
    else: ingest_candidate(args.candidate_id, args.election_cycle)
