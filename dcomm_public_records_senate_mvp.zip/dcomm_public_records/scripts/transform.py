from pathlib import Path
import duckdb
ROOT = Path(__file__).resolve().parents[1]
DB = ROOT / "data" / "dcomm_public_records.duckdb"
con = duckdb.connect(str(DB))
con.execute("""
CREATE OR REPLACE VIEW mart_senate_top_donors AS
SELECT
  f.candidate_id,
  ca.candidate_name,
  f.contributor_id,
  max(f.contributor_name_raw) AS contributor_name,
  max(cr.employer) AS employer,
  max(cr.occupation) AS occupation,
  max(cr.state) AS contributor_state,
  sum(f.amount) AS total_contributed,
  count(*) AS transaction_count
FROM fact_contributions f
LEFT JOIN candidates ca ON ca.candidate_id=f.candidate_id
LEFT JOIN contributors cr ON cr.contributor_id=f.contributor_id
LEFT JOIN committees cm ON cm.committee_id=f.committee_id
WHERE cm.committee_id IS NOT NULL
GROUP BY 1,2,3
""")
print(con.execute("select count(*) from candidates where office='S'").fetchone()[0], "Senate candidate records")
con.close()
