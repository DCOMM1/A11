from pathlib import Path
import duckdb

ROOT = Path(__file__).resolve().parents[1]
db_path = ROOT / "data" / "dcomm_public_records.duckdb"
schema = (ROOT / "sql" / "001_schema.sql").read_text()
con = duckdb.connect(str(db_path))
con.execute(schema)
con.close()
print(f"Initialized {db_path}")
