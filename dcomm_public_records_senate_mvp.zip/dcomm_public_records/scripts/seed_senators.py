from pathlib import Path
import csv, duckdb
ROOT=Path(__file__).resolve().parents[1]
DB=ROOT/'data/dcomm_public_records.duckdb'
CSV=ROOT/'data/senate_roster_119.csv'
con=duckdb.connect(str(DB))
with CSV.open() as f:
    for r in csv.DictReader(f):
        oid='SEN-'+r['state']
        con.execute('''INSERT OR REPLACE INTO officials
        (official_id,full_name,office_level,office_type,jurisdiction,state,party,current_status,source_url)
        VALUES (?,?,?,?,?,?,?,?,?)''', [oid,r['full_name'],'federal','US Senate','United States',r['state'],r['party'],'current','https://www.senate.gov/senators/index.htm'])
print('Seeded', con.execute("select count(*) from officials where office_type='US Senate'").fetchone()[0], 'Senate officials')
con.close()
