from pathlib import Path
import duckdb

def test_schema(tmp_path):
    db=tmp_path/"test.duckdb"
    con=duckdb.connect(str(db))
    con.execute((Path(__file__).parents[1]/"sql/001_schema.sql").read_text())
    tables={r[0] for r in con.execute("show tables").fetchall()}
    assert {"officials","candidates","committees","contributors","fact_contributions"} <= tables
